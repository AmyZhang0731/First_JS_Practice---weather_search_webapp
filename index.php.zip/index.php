<html>
<head>
    <title>
        Forecast Search
    </title>
    <style>
        div#sea{
            border: 3px solid;
            padding: 5px 3px 0px 10px;
            width: 500px;
            height: 270px;
            line-height: 0.3em;
            font-size: 120%;
        }
        div#weather{
            border: 3px solid;
            padding-left: 150px;
            padding-top: 20px;
            padding-bottom: 20px;
            width: 460px;
            height: 400px;
            line-height: 0.2em;
            font-size: 120%;
        }
        h1{
            margin-left: 150px;
        }
        th{
            text-align: center;
            font-size: 200%;
        }
        table{
            width: 350px;
            height: 350px;
        }
    </style>
</head>
    
<body id="whole">
    <script language="JavaScript">
        function verify(form)
        {   
            if(form.street.value=="") 
                alert("Please enter value for Street");
            else if(form.city.value=="")
                alert("Please enter value for City");
        }
        
        function clean(form)
        {
            form.street.value="";
            form.city.value="";
            from.state.option[0].selected=true;
            from.degree.value="Fahrenheit";
        }
   
    </script>
    
    <h1>Forecast Search</h1>
    <div id="sea"><form action="" method="POST">
        <p>Street Address:*<input type="text" name="street" value="" size=20></p>
        <p>City:*<input style="margin-left: 80px" type="text" name="city" value="" size=20></p>
        <p>State:*<select style="margin-left: 75px" name="state" data-default-value="Select your State...">
            <option value="" SELECTED>Select your State...</option>
            <option value="Alabama">Alabama</option>
            <option value="Alaska">Alaska</option>
            <option value="Arizona">Arizona</option>
            <option value="Arkansas">Arkansas</option>
            <option value="California">California</option>
            <option value="Colorado">Colorado</option>
            <option value="Connecticut">Connecticut</option>
            <option value="Delaware">Delaware</option>        
            <option value="District Of Columbia">District Of Columbia</option>
            <option value="Florida">Florida</option>
            <option value="Georgia">Georgia</option>
            <option value="Hawaii">Hawaii</option>
            <option value="Idaho">Idaho</option>
            <option value="Illinois">Illinois</option>
            <option value="Indiana">Indiana</option>
            <option value="Iowa">Iowa</option>
            <option value="Kansas">Kansas</option>
            <option value="Kentucky">Kentucky</option>
            <option value="Louisiana">Louisiana</option>
            <option value="Maine">Maine</option>
            <option value="Maryland">Maryland</option>
            <option value="Massachusetts">Massachusetts</option>
            <option value="Michigan">Michigan</option>
            <option value="Minnesota">Minnesota</option>
            <option value="Mississippi">Mississippi</option>
            <option value="Missouri">Missouri</option>
            <option value="Montana">Montana</option>
            <option value="Nebraska">Nebraska</option>
            <option value="Nevada">Nevada</option>
            <option value="New Hampshire">New Hampshire</option>
            <option value="New Jersey">New Jersey</option>
            <option value="New Mexico">New Mexico</option>
            <option value="New York">New York</option>
            <option value="North Carolina">North Carolina</option>
            <option value="North Dakota">North Dakota</option>
            <option value="Ohio">Ohio</option>
            <option value="Oklahoma">Oklahoma</option>
            <option value="Oregon">Oregon</option>
            <option value="Pennsylvania">Pennsylvania</option>
            <option value="Rhode Island">Rhode Island</option>
            <option value="South Carolina">South Carolina</option>
            <option value="South Dakota">South Dakota</option>
            <option value="Tennessee">Tennessee</option>
            <option value="Texas">Texas</option>
            <option value="Utah">Utah</option>
            <option value="Vermont">Vermont</option>
            <option value="Virginia">Virginia</option>
            <option value="Washington">Washington</option>
            <option value="West Virginia">West Virginia</option>
            <option value="Wisconsin">Wisconsin</option>
            <option value="Wyoming">Wyoming</option>
        </select></p>
        <p>Degree:*<input style="margin-left: 58px" type="radio" name="degree" value="Fahrenheit" CHECKED>Fahrenheit
        <input type="radio" name="degree" value="Celsius">Celsius</p>
        <input style="margin-left: 128px"type="submit" name="search" value="Search" onClick="(verify(this.form))">
        <input type="reset" name="clear" value="Clear" onClick="(clean(this.form))">
    </form>
        <p style="font-size: 90%"><I>*-Mandatory fields.</I></p><br><br>
        <a style="margin-left: 150px;" href="http://forecast.io/">Powered by Forecast.io</a>
    </div>
    <?php   $defaultTimeZone='America/Los_Angeles';
            date_default_timezone_set($defaultTimeZone);
            if(isset($_POST["search"]) && ($_POST["street"]!="") && ($_POST["city"]!="")): ?>
    <?php $street=$_POST["street"]; $city=$_POST["city"];
            switch ($_POST["state"])
            {   
                case "Alabama": $state="AL";break;
                case "Alaska": $state="AK";break;
                case "Arizona": $state="AZ";break;
                case "Arkansas": $state="AR";break;
                case "California": $state="CA";break;
                case "Colorado": $state="CO";break;
                case "Connecticut": $state="CT";break;
                case "Delaware": $state="DE";break;
                case "District Of Columbia": $state="CD";break;
                case "Florida": $state="FL";break;
                case "Georgia": $state="GA";break;
                case "Hawaii": $state="HI";break;
                case "Idaho": $state="ID";break;
                case "Illinois": $state="IL";break;
                case "Indiana": $state="IN";break;
                case "Iowa": $state="IA";break;
                case "Kansas": $state="KS";break;
                case "Kentucky": $state="KY";break;
                case "Louisiana": $state="LA";break;
                case "Maine": $state="ME";break;
                case "Maryland": $state="MD";break;
                case "Massachusetts": $state="MA";break;
                case "Michigan": $state="MI";break;
                case "Minnesota": $state="MN";break;
                case "Mississippi": $state="MS";break;
                case "Missouri": $state="MO";break;
                case "Montana": $state="MT";break;
                case "Nebraska": $state="NE";break;
                case "Nevada": $state="NV";break;
                case "New Hampshire": $state="NH";break;
                case "New Jersey": $state="NJ";break;
                case "New Mexico": $state="NM";break;
                case "New York": $state="NY";break;
                case "North Carolina": $state="NC";break;
                case "Ohio": $state="OH";break;
                case "Oklahoma": $state="OK";break;
                case "Oregon": $state="OR";break;
                case "Pennsylvania": $state="PA";break;
                case "Rhode Island": $state="RI";break;
                case "South Carolina": $state="SC";break;
                case "South Dakota": $state="SD";break;
                case "Tennessee": $state="TN";break;
                case "Texas": $state="TX";break;
                case "Utah": $state="UT";break;
                case "Vermont": $state="VT";break;
                case "Virginia": $state="VA";break;
                case "Washington": $state="WA";break;
                case "West Virginia": $state="WV";break;
                case "Wisconsin": $state="WI";break;
                case "Wyoming": $state="WY";break;
                default: $state="";break;
            }
            switch ($_POST["degree"])
            {
                case "Fahrenheit": {$degree="us";$unit="F";}break;
                case "Celsius": {$degree="si";$unit="C";}break;
                default: $degree="";break;
            }
            $geocodeurl="http://maps.google.com/maps/api/geocode/xml?address=".$street.",".$city.",".$state;
            $geoxml=simplexml_load_file($geocodeurl);
            $lat=$geoxml->result->geometry->location->lat;
            $lng=$geoxml->result->geometry->location->lng;
            $mykey="0cb4c308b597a4d4d04786315b34f697";
            $forecasturl="https://api.forecast.io/forecast/"
                        .$mykey."/".$lat.",".$lng."?units=".$degree."&exclude=flags";

            $json = file_get_contents($forecasturl);
            $jsonfile = json_decode($json,true);

            $condition=$jsonfile['currently']['summary'];
            $temp=ceil($jsonfile['currently']['temperature']);
            $icon=$jsonfile['currently']['icon'];
            $pre=$jsonfile['currently']['precipIntensity'];
            $rain=($jsonfile['currently']['precipProbability'])*100;
            $wind=ceil($jsonfile['currently']['windSpeed']);
            $due=ceil($jsonfile['currently']['dewPoint']);
            $humidity=($jsonfile['currently']['humidity'])*100;
            $visibility=ceil($jsonfile['currently']['visibility']);
            $sunrise=date("h:i a", $jsonfile['daily']['data'][0]['sunriseTime']);
            $sunset=date("h:i a", $jsonfile['daily']['data'][0]['sunsetTime']);

            switch ($icon)
            {
                case "clear-day": $image="clear.png";break;
                case "clear-night": $image="clear_night.png";break;
                case "rain": $image="rain.png";break;
                case "snow": $image="snow.png";break;
                case "sleet": $image="sleet.png";break;
                case "wind": $image="clear.png";break;
                case "fog": $image="wind.png";break;
                case "cloudy": $image="cloudy.png";break;
                case "partly-cloudy-day": $image="cloud_day.png";break;
                case "partly-cloudy-night": $image="cloud_night.png";break;
            }

            switch ($pre)
            {
                case 0: $precip="None";break;
                case 0.002: $precip="Light";break;
                case 0.017: $precip="Very Light";break;
                case 0.01: $precip="Moderate";break;
                case 0.04: $precip="Heavy";break;
            }
            
            echo "<br><br><div id=\"weather\"><table border=0><tr><th>".$condition;
            echo "</th></tr><tr><th>".$temp.htmlentities("°")." ".$unit;
            echo "</th></tr><tr><th><img src=".$image;
            echo " alt=".$icon.">";
            echo "</th></tr><tr><td>Precipitation:</td><td>".$precip;
            echo "</td></tr><tr><td>Chance of Rain:</td><td>".$rain;
            echo "%</td></tr><tr><td>Wind Speed:</td><td>".$wind;
            echo " mph</td></tr><tr><td>Dew Point:</td><td>".$due;
            echo "</td></tr><tr><td>Humidity:</td><td>".$humidity;
            echo "%</td></tr><tr><td>Visibility:</td><td>".$visibility;
            echo " mi</td></tr><tr><td>Sunrise:</td><td>".$sunrise;
            echo "</td></tr><tr><td>Sunset:</td><td>".$sunset;
            echo "</td></tr></table></div>";
            
?>
    <?php endif; ?>
     
    </body>
</html>